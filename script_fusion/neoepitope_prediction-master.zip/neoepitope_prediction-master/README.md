**Usage**

`./Immunopipe.sh --dna-bam /path/to/bam [--snvs /path/to/snv.vcf] [--indels /path/to/indel.vcf] [--fusions /path/to/arriba_fusions.tsv] [--fusion-confidence "medium high"] --output /path/to/output/directory --pid PID`

